<?php
$auth_host = "localhost";
$auth_user = "";
$auth_pass = "";
$auth_dbase = "";

$smtp_auth = false;
$smtp_host = "mail.deviongames.com";
$smtp_port = 25;
$smtp_user = "noreply@deviongames.com";
$smtp_password = "";
?>
